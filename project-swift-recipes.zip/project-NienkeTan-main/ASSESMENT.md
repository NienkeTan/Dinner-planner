Belangrijk! 
Ik heb de app gemaakt met de simulator op iPhone 11. Door tijdsnood is het niet gelukt om alles aan te passen zodat het er goed uitziet op andere iphones.

# Aandachtspunten
1. Bijhouden variabelen in class i.p.v. los. Variabelen die nodig waren in elke View stuurde ik mee als binding parameter. Dit zorgde voor minder overzicht en daarmee werd het opslaan van de variabelen niet mogelijk. Ik heb ze allemaal in een class gezet waarmee ik ze kon aanroepen via 'EnvironmentObject'. 
2. UIImage kan je niet opslaan in UserDefaults. Uiteindelijk heb ik ze hier wel in opgeslagen na ze te comprimeren en te converteren naar Data.
3. Acties die repetitief werden of acties die het overzicht van de View verstoorden in functies gezet.


# Grote beslissingen
1. In eerste instantie wilde ik een planner maken met een kalender waarmee je weken vooruit kon plannen en de datum weergeeft. Na wat online te hebben gezocht kwam ik tot de conclusie dat dit al een heel project op zich was en iets te ingewikkeld was voor hetgeen dat ik wilde maken. Er waren een aantal open source kalenders om te gebruiken, maar ik vond dat ik hiermee niet het doel van dit vak aan het nastreven was. Dus ik maakte de beslissing om slechts 1 week te laten zien zonder datum met als resultaat dat de app heel schoon en minimalistisch uitziet. Het heeft goed uitgepakt.

