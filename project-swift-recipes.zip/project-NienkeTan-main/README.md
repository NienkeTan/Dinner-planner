# Project Dinner Planner App
project-NienkeTan created by GitHub Classroom
Ontwikkelaar: Nienke Tan

## Dinner Planner
Met deze 'Dinner Planner' App kun je gemakkelijk je avondeten plannen aan het begin van elke week. Recepten zijn zelf toe te voegen met daarbij een notitieveld om jezelf te herinneren aan specifieke benodigdheden of bereidingswijzen van het recept. Upload daarbij een foto en je kunt nu het recept toevoegen aan een dag in de komende week. Verwijder een recept door op het knopje 'edit' te drukken. 
Plan een of meerdere recepten in om het overzicht te bewaren.

<img src="doc/Simulator Screen Shot - iPhone 11 - 2022-05-31 at 17.15.20.png" width="250" /> <img src="doc/Simulator Screen Shot - iPhone 11 - 2022-05-31 at 17.15.49.png" width="250" />

# Credits
De imagepicker is overgenomen van:
https://designcode.io/swiftui-advanced-handbook-imagepicker

Default recept foto, geen licensie:
https://pxhere.com/nl/photo/1440151

Opslaan in Userdefaults:
https://www.hackingwithswift.com/books/ios-swiftui/saving-and-loading-data-with-userdefaults

# Demonstratie
Link naar video: https://video.uva.nl/media/t/0_shq5ow5h 

https://user-images.githubusercontent.com/71008317/171472489-d86b513a-4c46-4c11-b38a-c069cf5fd60b.mp4

