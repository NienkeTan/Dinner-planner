//
//  ProjectApp.swift
//  Project
//
//  Created by Nienke Tan on 29/04/2022.
//

import SwiftUI

@main
struct ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
