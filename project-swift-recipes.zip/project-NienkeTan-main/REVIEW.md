Review studenten: Moussa en Nina

# Feedback
1. Stijl van code is niet consistent. Op veel plekken zijn de enters en spaties niet logisch.
2. Constantes bovenaan de ContentView kunnen beter in een struct. Die zijn nog steeds makkelijk aan te roepen dan, maar het staat zo wat netter.
3. Sheets beter aan een aparte file toevoegen in plaats van de file van de View waarin hij voorkomt.
4. Hoofdletter conventies met Swift zijn niet altijd toegepast, bijvoorbeeld in de functienamen. 
